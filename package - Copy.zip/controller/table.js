var express = require('express');
var router = express.Router();
var Sequelize = require('sequelize');
var dateTime = require('node-datetime');

const {
    base64encode,
    base64decode
} = require('nodejs-base64');

var Table = require("../model/table");
var mailer = require("./mail");



const insertvalue = async(req, res) => {
    try {
        // console.log(req.body);
        var title = req.body.title;
        var description = req.body.description;
        var author = req.body.author;
        var dt = dateTime.create();
        var date = dt.format('Y-m-d H:M:S');

        await Table.create({
            title: title,
            description: description,
            author: author,
            created_date: date
        }).then(function(users) {
            if (users) {
                mailer("from amil", "to mail", "subject", "text");
                res.send({ status: 1 });
            } else {
                res.status(400).send('Error in insert new record');
            }
        });

    } catch (err) {
        throw Error(err);
    }
}



const getallvalue = async(req, res) => {
    try {

        await Table.findAll({
            attributes: ["title", 'description', 'author', [Sequelize.fn('date_format', Sequelize.col('created_date'), '%d-%M-%Y'), 'created_date']]
        }).then(function(users) {
            if (users) {
                res.send(users);
            } else {
                res.status(400).send('Error in select record');
            }
        });

    } catch {
        throw Error("Error bad request.");
    }
}



const getvalueby_authorid = async(req, res) => {
    try {

        await Table.findAll({
            attributes: ["title", 'description', 'author', [Sequelize.fn('date_format', Sequelize.col('created_date'), '%d-%M-%Y'), 'created_date']],
            where: {
                author: req.body.author
            }
        }).then(function(users) {
            if (users) {
                res.send(users);
            } else {
                res.status(400).send('Error in select record');
            }
        });

    } catch {
        throw Error("Error bad request.");
    }
}



const deletepost = async(req, res) => {
    try {

        await Table.destroy({
            where: {
                blog_id_pk: req.body.id
            }
        }).then(function(users) {
            if (users) {
                res.send({ status: 1 });
            } else {
                res.status(400).send('Error in select record');
            }
        });

    } catch {
        throw Error("Error bad request.");
    }
}


const updatevalue = async(req, res) => {
    try {

        var dt = dateTime.create();
        var date = dt.format('Y-m-d H:M:S');

        await Table.update({ title: req.body.title, description: req.body.description, author: req.body.author, created_date: date }, {
            where: {
                blog_id_pk: req.body.id

            },
            returning: true,
            plain: true
        }).then(function(users) {
            if (users) {
                res.send({ status: 1 });
            } else {
                res.status(400).send('Error in select record');
            }
        });

    } catch {
        throw Error("Error bad request.");
    }
}


module.exports = {
    insertvalue,
    getallvalue,
    getvalueby_authorid,
    deletepost,
    updatevalue
}