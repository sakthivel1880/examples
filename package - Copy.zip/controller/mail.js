var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'your mail id',
        pass: 'your pass'
    }
});



const mailer = async(from, to, subject, text) => {
    try {
        var mailOptions = {
            from: from,
            to: to,
            subject: subject,
            text: text
        };
        // console.log(mailOptions);
        await transporter.sendMail(mailOptions, function(error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log('Email sent: ' + info.response);
            }
        });
    } catch {
        throw Error("Error bad request.");
    }
}

module.exports = mailer;