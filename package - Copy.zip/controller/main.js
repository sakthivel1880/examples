const express = require('express');
var router = express.Router();

const table = require('./table');

router.post('/insert/', table.insertvalue);
router.get('/select/', table.getallvalue);
router.post('/authorid/', table.getvalueby_authorid);
router.post('/delete/', table.deletepost);
router.post('/update/', table.updatevalue);


module.exports = router;