var Sequelize = require('sequelize');
var db = require("./config");

module.exports = db.sequelize.define(
    'tbl_blog', {
        blog_id_pk: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        title: {
            type: Sequelize.STRING,
        },
        description: {
            type: Sequelize.STRING,
        },
        author: {
            type: Sequelize.INTEGER
        },
        created_date: {
            type: Sequelize.DATE,
            defaultValue: Sequelize.NOW
        },
    }, {
        timestamps: false,
        freezeTableName: true
    }
);