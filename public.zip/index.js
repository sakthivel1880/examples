const express = require('express');
require('./model/db');

const bodyparser = require('body-parser');
const cors = require('cors');
const path = require('path');
const { urlencoded } = require('body-parser');

//controller
const Main = require('./controller/main');


var app = express();
app.use(cors());
app.use(bodyparser.urlencoded({
    extended: true
}));
app.use(bodyparser.json());
app.use(express.static(__dirname + 'public'));

app.set('port', process.env.PORT || 8000);

app.listen(8000, () => {
    console.log("nodejs running this port.");
});


app.use('/main/', Main);