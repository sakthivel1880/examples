const mongoose = require('mongoose');
const url = "mongodb://localhost:27017/Examples";

mongoose.connect(url, { useUnifiedTopology: true, useNewUrlParser: true, useFindAndModify: false }, (err) => {
    if (!err) { console.log("MongoDB Connection Succeeded"); } else {
        console.log("An Error Occured");
    }
});

require('./form.model');