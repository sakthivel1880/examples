const path = require("path");
var multer = require('multer');


var storagead = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'public/images/')
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname)
    }
});

const uploadad = multer({
    storage: storagead
}).fields([{ name: "image", maxCount: 1 }]);

module.exports = {
    uploadad
}