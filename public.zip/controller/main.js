const express = require('express');
var router = express.Router();

const form = require('./form');

router.post('/insert/', form.insertvalue);
router.get('/select/', form.selectvalue);
router.post('/delete/', form.deletevalue);
router.post('/selectbyid/', form.selectvaluebyid);
router.post('/update/', form.updatevalue);
// router.post('/insert/', (req, res) => {
//     console.log(req);
// })

module.exports = router;