const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
// const upload = require('../middleware/fileupload');

//model

const Form = mongoose.model('form');

const insertvalue = async(req, res) => {
    // console.log(req);
    // upload.uploadad;
    try {
        var form = new Form();
        form.name = req.body.name;
        form.email = req.body.email;
        form.address = req.body.address;
        // form.image = req.files['image'][0]['filename'];
        form.gender = req.body.gender;
        await form.save((err, docs) => {
            // console.log(docs);
            if (!err)
                res.send({ status: 1 });
            else
                res.send({ status: 0 });
        })
    } catch {
        throw Error("Error bad request.");
    }
}

const selectvalue = async(req, res) => {
    try {
        await Form.find((err, docs) => {
            if (!err) {
                res.send(docs);
            }
        })
    } catch {
        throw Error("Error bad request.");
    }
}

const deletevalue = async(req, res) => {
    try {
        await Form.findByIdAndRemove(req.body.id, (err, docs) => {
            if (!err) {
                res.send(docs);
            }
        })
    } catch {
        throw Error("Error bad request.");
    }
}

const selectvaluebyid = async(req, res) => {
    try {
        await Form.find({ _id: req.body.id }, (err, docs) => {
            if (!err) {
                res.send(docs);
            }
        })
    } catch {
        throw Error("Error bad request.");
    }
}


const updatevalue = async(req, res) => {
    try {
        await Form.findByIdAndUpdate({ _id: req.body.id }, req.body, { new: true }, (err, docs) => {
            if (!err) {
                if (!err)
                    res.send({ status: 1 });
                else
                    res.send({ status: 0 });
            }
        })
    } catch {
        throw Error("Error bad request.");
    }
}

module.exports = {
    insertvalue,
    selectvalue,
    deletevalue,
    selectvaluebyid,
    updatevalue
}