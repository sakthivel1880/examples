import React, { Component } from 'react';
import axios from 'axios';
import { ApiUrl } from '../config/config';

class Table extends Component {
    constructor(props) {
        super(props);
        this.state={
            values:[]
        }
    }
    
    getData(){
        axios.get(ApiUrl+'main/select/').then(result=>{
            this.setState({values:result.data});
        });
    }

    delete=(e,id)=>{
        axios.post(ApiUrl+'main/delete/',{id:id}).then((res)=>{
            this.getData();
        })
    }

    componentDidMount(){
        this.getData();
    }
    render() {

        return (
            <div>
            <div className="container">
                <a href="http://localhost:3001/" className="btn btn-primary">Add</a>
                <br/>
            <div className="table-responsive">
            <table className="table">
                <tr>
                    <th>UserName</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Gender</th>
                    <th>Action</th>
                </tr>
                {this.state.values.map((key,value)=>{ 
            return (<tr>
                <td>
                    {key.name}
                </td>
                <td>
                    {key.email}
                </td>
                <td>
                    {key.address}
                </td>
                <td>
                    {key.gender}
                </td>
                <td>
                    <a href={"/"+key._id} className="btn btn-info">Edit</a>
                    <a href="javascript:void(0)" onClick={e=>{this.delete(e,key._id)}} className="btn btn-danger">Delete</a>
                </td>
            </tr>)
        })}
                </table> 
            </div>
            </div>
            </div>
        );
    }
}

export default Table;