import React, { Component } from 'react';
import axios from 'axios';
import { ApiUrl } from '../config/config';

class Forms extends Component {
    constructor(props){
        super(props);
        this.state={
            id : '',
            name : '',
            email : '',
            address : '',
            gender : '',
            values:[]
            // image : ''
        }
    }

    onchange = (e) =>{
       this.setState({[e.target.name]: e.target.value})
    }

    // onchangefile = (e) =>{
    //     this.setState({
    //         [e.target.name] : e.target.files[0]
    //     });
    // }

    onsubmit = () =>{ 
        // let form_data = new FormData();
        // form_data.append('name', this.state.name);
        // form_data.append('image', this.state.image);
        // form_data.append('email', this.state.email);
        // form_data.append('address', this.state.address);
        // form_data.append('gender', this.state.gender);

        if(this.state.id == ""){
        axios.post(ApiUrl+'main/insert/',this.state).then((ressult)=>{ 
            if(ressult.data.status == 1){
                alert("succss");
                this.resetData();
                this.getData();
            } else {
                alert("failed");
            }
        });
    } else {
        axios.post(ApiUrl+'main/update/',this.state).then((ressult)=>{ 
            if(ressult.data.status == 1){
                alert("succss");
                this.resetData();
                this.getData();
            } else {
                alert("failed");
            }
        });
    }
    }

    resetData()
    {
        this.setState({
            id : '',
            name : '',
            email : '',
            address : '',
            gender : '',
            // image : ''
            values:[]
        })
    }

    
    getData(){
        axios.get(ApiUrl+'main/select/').then(result=>{
            this.setState({values:result.data});
        });
    }

    delete=(e,id)=>{
        axios.post(ApiUrl+'main/delete/',{id:id}).then((res)=>{
            this.getData();
        })
    }

    edit=(e,id)=>{
        axios.post(ApiUrl+'main/selectbyid/',{id:id}).then(result=>{
            this.setState({
                name:result.data[0].name,
                email:result.data[0].email,
                address:result.data[0].address,
                gender:result.data[0].gender,
                id:result.data[0]._id,
            });
        });
    }
    componentDidMount(){
        this.getData();
    }
    render() {
        return (
            <>
        <div className="container">
        <form>
            <div className="form-group">
            <label htmlFor="inputEmail4">UserName</label>
            <input type="text" className="form-control" onChange={e=>{this.onchange(e)}} name="name" value={this.state.name} id="inputName4" placeholder="UserName" />
            </div>
            <div className="form-group">
            <label htmlFor="inputEmail4">Email</label>
            <input type="email" className="form-control" onChange={e=>{this.onchange(e)}} name="email" value={this.state.email} id="inputEmail4" placeholder="Email" />
            </div>
        <div className="form-group">
            <label htmlFor="inputAddress">Address</label>
            <input type="text" className="form-control" onChange={e=>{this.onchange(e)}} name="address" value={this.state.address} id="inputAddress" placeholder="1234 Main St" />
        </div>
        {/* <div className="form-group">
            <label htmlFor="inputImage">Image</label>
            <input type="file" className="form-control" onChange={e=>{this.onchangefile(e)}} name="image" id="inputImage" />
        </div> */}
            <div className="form-group">
            <label htmlFor="inputGender">Gender</label>
            <select id="inputGender" name="gender" onChange={e=>{this.onchange(e)}} className="form-control">
                <option>Choose...</option>
                <option {...this.state.gender=="male" ? "":""} value="male">Male</option>
                <option {...this.state.gender=="female" ? "":""}value="female">Female</option>
                <option {...this.state.gender=="other" ? "":""} value="other">Other</option>
            </select>
            </div>
        <div className="form-group">
            <div className="form-check">
            <input className="form-check-input" type="checkbox" id="gridCheck" />
            <label className="form-check-label" htmlFor="gridCheck">
                Check me out
            </label>
            </div>
        </div>
        <button type="button" className="btn btn-primary"  onClick={e=>{this.onsubmit()}}>Save</button>
        </form>
        <div className="table-responsive">
            <table className="table">
                <tr>
                    <th>UserName</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Gender</th>
                    <th>Action</th>
                </tr>
                {this.state.values.map((key,value)=>{ 
            return (<tr>
                <td>
                    {key.name}
                </td>
                <td>
                    {key.email}
                </td>
                <td>
                    {key.address}
                </td>
                <td>
                    {key.gender}
                </td>
                <td>
                    <a href="javascript:void(0)" onClick={e=>{this.edit(e,key._id)}} className="btn btn-info">Edit</a>
                    <a href="javascript:void(0)" onClick={e=>{this.delete(e,key._id)}} className="btn btn-danger">Delete</a>
                </td>
            </tr>)
        })}
                </table> 
            </div>
        </div></>
        );
    }
}

export default Forms;